export default()=>
{
    return(
        <div style={{margin:"10%"}}>
            <h1>Page Not Found</h1>
            <ul>
                <li>Check the url and try again</li>
                <li>Check the internet connection</li>
            </ul>
        </div>
    )
}